package com.lti.entity;

public enum AccountType {
  SAVINGS,CURRENT,DEMAT
}
