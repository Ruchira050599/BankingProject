package com.lti.entity;

public enum TransferType {
	NEFT,RTGS,IMPS
}
