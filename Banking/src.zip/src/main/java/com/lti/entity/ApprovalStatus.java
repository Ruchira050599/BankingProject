package com.lti.entity;

public enum ApprovalStatus {
 APPROVED,REJECTED,APPLIED
}
